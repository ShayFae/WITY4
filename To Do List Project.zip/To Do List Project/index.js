// state variables
let todoList = []

// ui variables
const form = document.querySelector(".form")
const input = document.querySelector(".form__input")
const ul = document.querySelector(".todoList")


/**
 * Event Listeners...
 */

form.addEventListener('submit', event => {

    event.preventDefault() // prevent default behaviour, without this, the default behaviour is to reload the page when a form is submitted!

    addTodo(input.value) // get value from input and send into todo list

    input.value = '' // clear the input box.
})

ul.addEventListener('click', event => {

    const domElement = event.target // get clicked DOM element

    // if the clicked item is not a todo list item, ignore click event
    // click events can be triggered on elements that aren't todo elements
    if (false === domElement.matches(".todoList li")){
        return
    }

    removeTodo(domElement)
})

/**
 * Functions...
 */

function addTodo(todoText)
{
  


    // Write code to generate todo a unique ID, so we can find it in the array when removing. 
    // This can be done using current date.
    // Write code to add item to array as an object with the ID.



    const li = document.createElement('li') // create an element to insert the todo text into...
    li.innerText = todoText // add todo text to li
    li.setAttribute("data-id", id) // give the element that ID we made earlier

    ul.appendChild(li) // add li to the DOM, inside the ul list
}

function removeTodo(domElement)
{
    const id = domElement.getAttribute("data-id") // get ID from element



    
    // Write code to filter item from array
    // write code to delete the element

}
